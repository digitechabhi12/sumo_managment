sap.ui.define(["sap/ui/core/mvc/Controller"],r=>{"use strict";return r.extend("portal.controller.dashboard",{onInit(){}})});
//# sourceMappingURL=dashboard.controller.js.map